G04 Filename: part_4_antenna_gerber.gts*
G04 FileFunction: Soldermask,Top*
G04 Part: Single*
G04 ProjectId: part_4_antenna_gerber,EF8224D4D3E534975D98E4CC69108CE2,1*
G04 GenerationSoftware: MathWorks,MATLAB,26.1.0.3251617 (R2026a) Update 2*
G04 CreationDate: 2026-07-12T14:56:79-0400*
G04 FilePolarity: Positive*
%FSLAX26Y26*%
%MOMM*%
G04 Clear soldermask for edge connector*
%LPD*%
G36*
G01*
X-65632134Y-03500000D02*
X-61432134D01*
Y03500000D01*
X-65632134D01*
Y-03500000D01*
D02*
G37*
G04 MD5: c170ffee2d39bdc6d9fb2935352c86172a2af4f9dd627815b76a19294ac82993a2d7ce6a7e151049e0dcb6d3995752e2b24d3e3577df67c40a2cdc56ff2*
M02*
